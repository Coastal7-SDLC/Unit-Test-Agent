import pytest
from mytoy.toys import toy

def test_toy_default_value():
    # Arrange
    expected = 1
    
    # Act
    result = toy()
    
    # Assert
    assert result == expected

def test_toy_positive_value():
    # Arrange
    n = 5
    expected = 6
    
    # Act
    result = toy(n)
    
    # Assert
    assert result == expected

def test_toy_negative_value():
    # Arrange
    n = -3
    expected = -2
    
    # Act
    result = toy(n)
    
    # Assert
    assert result == expected

def test_toy_zero_value():
    # Arrange
    n = 0
    expected = 1
    
    # Act
    result = toy(n)
    
    # Assert
    assert result == expected

def test_toy_large_positive_value():
    # Arrange
    n = 1000000
    expected = 1000001
    
    # Act
    result = toy(n)
    
    # Assert
    assert result == expected

def test_toy_large_negative_value():
    # Arrange
    n = -1000000
    expected = -999999
    
    # Act
    result = toy(n)
    
    # Assert
    assert result == expected